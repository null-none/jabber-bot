jabber-bot
====================

Class jabber bot on python

=======
Install
=======

.. code-block:: bash

    pip install jabber-bot



=======
License
=======

MIT
